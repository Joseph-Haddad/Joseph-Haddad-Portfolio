﻿#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment item.  By submitting this
#  code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
#    Student no: n10535268
#    Student name: Joseph Haddad
#
#  NB: Files submitted without a completed copy of this statement
#  will not be marked.  Submitted files will be subjected to
#  software plagiarism analysis using the MoSS system
#  (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assignment Description-----------------------------------------#
#
#  News Feed Aggregator
#
#  In this assignment you will combine your knowledge of HTMl/XML
#  mark-up languages with your skills in Python scripting, pattern
#  matching, and Graphical User Interface design to produce a useful
#  application that allows the user to aggregate RSS news feeds.
#  See the instruction sheet accompanying this file for full details.
#
#--------------------------------------------------------------------#



#-----Imported Functions---------------------------------------------#
#
# Below are various import statements for helpful functions.  You
# should be able to complete this assignment using these
# functions only.  Note that not all of these functions are
# needed to successfully complete this assignment.
#
# NB: You may NOT use any Python modules that need to be downloaded
# and installed separately, such as "Beautiful Soup" or "Pillow".
# Only modules that are part of a standard Python 3 installation may
# be used. 

# The function for opening a web document given its URL.
# (You WILL need to use this function in your solution,
# either directly or via our "download" function.)
from urllib.request import urlopen

# Import the standard Tkinter functions. (You WILL need to use
# these functions in your solution.  You may import other widgets
# from the Tkinter module provided they are ones that come bundled
# with a standard Python 3 implementation and don't have to
# be downloaded and installed separately.)
from tkinter import *

# Import a special Tkinter widget we used in our demo
# solution.  (You do NOT need to use this particular widget
# in your solution.  You may import other such widgets from the
# Tkinter module provided they are ones that come bundled
# with a standard Python 3 implementation and don't have to
# be downloaded and installed separately.)
from tkinter.scrolledtext import ScrolledText

# Functions for finding all occurrences of a pattern
# defined via a regular expression, as well as
# the "multiline" and "dotall" flags.  (You do NOT need to
# use these functions in your solution, because the problem
# can be solved with the string "find" function, but it will
# be difficult to produce a concise and robust solution
# without using regular expressions.)
from re import findall, finditer, MULTILINE, DOTALL

# Import the standard SQLite functions (just in case they're
# needed one day).
from sqlite3 import *

#
#--------------------------------------------------------------------#



#-----------------------------------------------------------
#
# A function to download and save a web document. If the
# attempted download fails, an error message is written to
# the shell window and the special value None is returned.
#
# Parameters:
# * url - The address of the web page you want to download.
# * target_filename - Name of the file to be saved (if any).
# * filename_extension - Extension for the target file, usually
#      "html" for an HTML document or "xhtml" for an XML
#      document or RSS Feed.
# * save_file - A file is saved only if this is True. WARNING:
#      The function will silently overwrite the target file
#      if it already exists!
# * char_set - The character set used by the web page, which is
#      usually Unicode UTF-8, although some web pages use other
#      character sets.
# * lying - If True the Python function will hide its identity
#      from the web server. This can be used to prevent the
#      server from blocking access to Python programs. However
#      we do NOT encourage using this option as it is both
#      unreliable and unethical!
# * got_the_message - Set this to True once you've absorbed the
#      message about Internet ethics.
#
def download(url = 'https://www.9news.com.au/rss',
             target_filename = '9NEWS',
             filename_extension = 'xhtml',
             save_file = True,
             char_set = 'UTF-8',
             lying = False,
             got_the_message = False):



    # Import the function for opening online documents and
    # the class for creating requests
    from urllib.request import urlopen, Request

    # Import an exception raised when a web server denies access
    # to a document
    from urllib.error import HTTPError

    # Open the web document for reading
    try:
        if lying:
            # Pretend to be something other than a Python
            # script (NOT RECOMMENDED!)
            request = Request(url)
            request.add_header('User-Agent', 'Mozilla/5.0')
            if not got_the_message:
                print("Warning - Request does not reveal client's true identity.")
                print("          This is both unreliable and unethical!")
                print("          Proceed at your own risk!\n")
        else:
            # Behave ethically
            request = url
        web_page = urlopen(request)
    except ValueError:
        print("Download error - Cannot find document at URL '" + url + "'\n")
        return None
    except HTTPError:
        print("Download error - Access denied to document at URL '" + url + "'\n")
        return None
    except Exception as message:
        print("Download error - Something went wrong when trying to download " + \
              "the document at URL '" + url + "'")
        print("Error message was:", message, "\n")
        return None

    # Read the contents as a character string
    try:
        web_page_contents = web_page.read().decode(char_set)
    except UnicodeDecodeError:
        print("Download error - Unable to decode document from URL '" + \
              url + "' as '" + char_set + "' characters\n")
        return None
    except Exception as message:
        print("Download error - Something went wrong when trying to decode " + \
              "the document from URL '" + url + "'")
        print("Error message was:", message, "\n")
        return None

    # Optionally write the contents to a local text file
    # (overwriting the file if it already exists!)
    if save_file:
        try:
            text_file = open(target_filename + '.' + filename_extension,
                             'w', encoding = char_set)
            text_file.write(web_page_contents)
            text_file.close()
        except Exception as message:
            print("Download error - Unable to write to file '" + \
                  target_filename + "'")
            print("Error message was:", message, "\n")

    # Return the downloaded document to the caller
    return web_page_contents

#
#--------------------------------------------------------------------#
######################################################################
#-----Student's Solution---------------------------------------------#
#
# Put your solution at the end of this file.
#

# Name of the exported news file. To simplify marking, your program
# should produce its results using this file name.
news_file_name = 'news.html'

#### My Solution ####

#### Live File Downloads

download('https://www.9news.com.au/rss','9NEWS') #### 9NEWS
download('https://www.news-mail.com.au/feeds/rss/homepage/','BUNDABERG') #### Bundaberg

##################################### ARCHIVED FILES CODE ###########################################

#### Archive 1 SBS ##########################
file_contents = open('sbs_news.xhtml', 'r', encoding = 'UTF-8')
news_contents = file_contents.read()

#### Link to the article
links_SBS = findall(r'<link>(.*?)</link>', news_contents)
#### Title/Heading of Article
title_SBS = findall(r'<title>(.*?)</title>', news_contents)
#### Publication Date
date_SBS = findall(r'<pubDate>(.*?)</pubDate>', news_contents)
#### Images
images_SBS = findall(r'<enclosure url="(.*?)\"', news_contents)
#### Description
description_SBS = findall(r'<description>(.*?)</description>', news_contents)


#### Archive 2 DAILY MAIL ##########################
file_contents2 = open('dailymail_news.xhtml', 'r', encoding = 'UTF-8')
news_contents2 = file_contents2.read()

#### Link to the article
links_DAILYMAIL = findall(r'url=\"(.*?)\"', news_contents2)
#### Title/Heading of Article
title_DAILYMAIL = findall(re.compile(r'<title>\n\t(.*?)\n      </title>',re.DOTALL), news_contents2)
#### Publication Date
date_DAILYMAIL = findall(r'<pubDate>(.*?)</pubDate>', news_contents2)
#### Images
images_DAILYMAIL = findall(r'<media:thumbnail url="(.*?)\"', news_contents2)
#### Description
description_DAILYMAIL = findall(re.compile(r'<description>(.*?)</description>',re.DOTALL), news_contents2)


##################################### LIVE FILES CODE ###########################################


#### Live 1 9NEWS ##########################
file_contents3 = open('9NEWS.xhtml', 'r', encoding = 'UTF-8')
news_contents3 = file_contents3.read()

#### Link to the article
links_9NEWS = findall(r'<link>(.*?)</link',news_contents3)
#### Title/Heading of Article
title_9NEWS = findall(r'<title>(.*?)</title>',news_contents3)
#### Publication Date
date_9NEWS = findall(r'<pubDate>(.*?)</pubDate>',news_contents3)
#### Images
images_9NEWS = findall(r'</media:content><media:thumbnail url=\"(.*?)\"',news_contents3)
#### Description
description_9NEWS = findall(r'<description>(.*?)</description>',news_contents3)


#### Live 2 BUNDABERG ##########################
file_contents4 = open('BUNDABERG.xhtml', 'r', encoding = 'UTF-8')
news_contents4 = file_contents4.read()

#### Link to the article
links_BUND = findall(r'<link>(.*?)</link>',news_contents4)
#### Title/Heading of Article
title_BUND = findall(r'<title>(.*?)</title>',news_contents4)
#### Publication Date
date_BUND = findall(r'<pubDate>(.*?)</pubDate>',news_contents4)
#### Images
images_BUND = findall(r'<media:content url=\"(.*?)\"',news_contents4)
#### Description
description_BUND = findall(r'<description>(.*?)</description>',news_contents4)


##################################### GUI ###########################################


user_interface = Tk()
user_interface.title('Haddad News')
user_interface.geometry('900x700')
user_interface.configure(bg ='light grey')

#### GUI Image
photo = PhotoImage(file = "logo_island_grey.png")
photo_label = Label(user_interface, image=photo, anchor = N, bg = 'light grey')


#### Haddad News Label
news_feed_label = Label(user_interface, text ='HADDAD NEWS',
                        font = ('Arial', 48),
                        fg = 'darkslateblue',
                        bg = 'light grey')

#### Scroll Bar
scrollbar = Scrollbar(user_interface)

##################################### (1 - 10) Selector Labels ###########################################

#### SBS Label
sbs_label = Label(user_interface, text ='SBS News Archive',
                  font = ('Arial', 18),
                  fg = 'black',
                  bg = 'light grey')

#### Daily Mail Label
dailymail_label = Label(user_interface, text ='Daily Mail News Archive',
                  font = ('Arial', 18),
                  fg = 'black',
                  bg = 'light grey')

#### 9 NEWS Label
news_9_label = Label(user_interface, text ='9 NEWS Live Feed',
                  font = ('Arial', 18),
                  fg = 'black',
                  bg = 'light grey')

#### Bundaberg Label
BUND_label = Label(user_interface, text ='Bundaberg News Live Feed',
                  font = ('Arial', 18),
                  fg = 'black',
                  bg = 'light grey')


##################################### Selection Function ###########################################




#### Selection Box --> This one is packed to display the information.

selection_box = Text(user_interface,
                        bg = 'light grey',
                        font = ('Arial', 18),
                        height = 10,
                        relief = 'ridge',
                        width = 40,
                        yscrollcommand = scrollbar.set,
                        wrap = WORD)

#### ------------------------------------------------------------ ####

#### Variable Storage

selection_box_SBS = Text(user_interface)
selection_box_DAILYMAIL = Text(user_interface)
selection_box_9NEWS = Text(user_interface)
selection_box_BUND = Text(user_interface)

#### SBS
hidden_selection = Text(user_interface)
description_selection = Text(user_interface)

#### Daily Mail
hidden_selection_DAILYMAIL = Text(user_interface)
description_selection_DAILYMAIL = Text(user_interface)

#### 9NEWS
hidden_selection_9NEWS = Text(user_interface)
description_selection_9NEWS = Text(user_interface)

#### Bundaberg
hidden_selection_BUND = Text(user_interface)
description_selection_BUND = Text(user_interface)

#### ------------------------------------------------------------ ####

#### List Selection and Display - (These empty lists are used to keep track of the users choice.)
b_BUND = []
c_BUND = []
b_9NEWS = []
c_9NEWS = []
b_DAILYMAIL = []
c_DAILYMAIL = []
b = []
c = []

def selection(*args):
    
#### ------------------------------------------------------------ ####
    
#### This selection function is in charge of formating the number
#### of selected items from each news source to either be displayed
#### in the gui - (title and date). Or to be displayed in the html
#### website page - (title, date, image links and descriptions.)

#### ------------------------------------------------------------ ####    

    #### SBS

    # - Keeps track of the users choice - #
    user_choice = int(variable.get())
    b.append(user_choice)
    user_choice = b[len(b)-1]
    c = list(range(0,user_choice))
    n = 0

    # - Clears the selection view in thr gui - #
    selection_box_SBS.delete('0.0', END)
    hidden_selection.delete('0.0', END)
    description_selection.delete('0.0', END)
    
    for value in c:
        if n <= len(c):
            
            # - Grabs the title, date, image link and description - #
            items = '"' + title_SBS[n+1] +'"\n'
            items2 = '[SBS - ' + date_SBS[n] + ']\n\n'                        
            selection_box_SBS.insert(END,items)
            selection_box_SBS.insert(END,items2)
            items3 = '<link>' + images_SBS[n] + '</link>'
            hidden_selection.insert(END,items3)
            items4 = description_SBS[n]
            description_selection.insert(END,items4)
            n = n + 1
#### ------------------------------------------------------------ ####

    #### Daily Mail

    # - Keeps track of the users choice - #
    user_choice_DAILYMAIL = int(variable2.get())
    b_DAILYMAIL.append(user_choice_DAILYMAIL)
    user_choice_DAILYMAIL = b_DAILYMAIL[len(b_DAILYMAIL)-1]
    c_DAILYMAIL = list(range(0,user_choice_DAILYMAIL))

    n_DAILYMAIL = 1

    # - Clears the selection view in thr gui - #
    selection_box_DAILYMAIL.delete('0.0', END)
    hidden_selection_DAILYMAIL.delete('0.0', END)
    description_selection_DAILYMAIL.delete('0.0', END)

    for value_DAILYMAIL in c_DAILYMAIL:
        if n_DAILYMAIL <= len(c_DAILYMAIL):

            # - Grabs the title, date, image link and description - #
            items_DAILYMAIL = '"' + title_DAILYMAIL[n_DAILYMAIL] +'"\n'
            items2_DAILYMAIL = '[Daily Mail - ' + date_DAILYMAIL[n_DAILYMAIL] + ']\n\n'                       
            selection_box_DAILYMAIL.insert(END,items_DAILYMAIL)
            selection_box_DAILYMAIL.insert(END,items2_DAILYMAIL)
            items3_DAILYMAIL = '<link>' + images_DAILYMAIL[n_DAILYMAIL] + '</link>'
            hidden_selection_DAILYMAIL.insert(END,items3_DAILYMAIL)
            items4_DAILYMAIL = description_DAILYMAIL[n_DAILYMAIL+1]
            description_selection_DAILYMAIL.insert(END,items4_DAILYMAIL)
                       
            n_DAILYMAIL = n_DAILYMAIL + 1

#### ------------------------------------------------------------ ####

    #### 9 News

    # - Keeps track of the users choice - #
    user_choice_9NEWS = int(variable3.get())
    b_9NEWS.append(user_choice_9NEWS)
    user_choice_9NEWS = b_9NEWS[len(b_9NEWS)-1]
    c_9NEWS = list(range(0,user_choice_9NEWS))

    n_9NEWS = 0

    # - Clears the selection view in thr gui - #
    selection_box_9NEWS.delete('0.0', END)
    hidden_selection_9NEWS.delete('0.0', END)
    description_selection_9NEWS.delete('0.0', END)

    for value_9NEWS in c_9NEWS:
        if n_9NEWS <= len(c_9NEWS):

            # - Grabs the title, date, image link and description - #
            items2_9NEWS = '"' + title_9NEWS[n_9NEWS+1] + '"\n'
            items_9NEWS = '[9 NEWS - ' + date_9NEWS[n_9NEWS+1] + ']\n\n'
            selection_box_9NEWS.insert(END,items2_9NEWS)
            selection_box_9NEWS.insert(END,items_9NEWS)
            items3_9NEWS = '<link>' + images_9NEWS[n_9NEWS] + '</link>'
            hidden_selection_9NEWS.insert(END,items3_9NEWS)
            items4_9NEWS = description_9NEWS[n_9NEWS+1]
            description_selection_9NEWS.insert(END,items4_9NEWS)
            
            n_9NEWS = n_9NEWS + 1

#### ------------------------------------------------------------ ####  

    #### Bundaberg

    # - Keeps track of the users choice - #
    user_choice_BUND = int(variable4.get())
    b_BUND.append(user_choice_BUND)
    user_choice_BUND = b_BUND[len(b_BUND)-1]
    c_BUND = list(range(0,user_choice_BUND))

    n_BUND = 0

    # - Clears the selection view in thr gui - #
    selection_box_BUND.delete('0.0', END)
    hidden_selection_BUND.delete('0.0', END)
    description_selection_BUND.delete('0.0', END)

    for value_BUND in c_BUND:
        if n_BUND <= len(c_BUND):

           # - Grabs the title, date, image link and description - #
           items_BUND = '"' + title_BUND[n_BUND+1] + '"\n'
           items2_BUND = '[Bundaberg - ' + date_BUND[n_BUND+1] + ']\n\n'
           selection_box_BUND.insert(END,items_BUND)
           selection_box_BUND.insert(END,items2_BUND)
           items3_BUND = '<link>' + images_BUND[n_BUND] + '</link>'
           hidden_selection_BUND.insert(END,items3_BUND)
           items4_BUND = '<' + description_BUND[n_BUND+1] + '>'
           description_selection_BUND.insert(END,items4_BUND)

           n_BUND = n_BUND + 1


#### ------------------------------------------------------------ ####

    ##### SBS Display - (This stores the users selected stories.)
    sbs_box = []
    sel = selection_box_SBS.get('1.0',END)
    sbs_box.append(sel)
    
    #### Daily Mail Display - (This stores the users selected stories.)
    dailymail_box = []
    sel2 = selection_box_DAILYMAIL.get('1.0',END)
    sel2_1 = findall(re.compile(r'"\n\t(.*?)\n      "',re.DOTALL), sel2)
    dailymail_box.append(sel2)

    #### 9 NEWS Display - (This stores the users selected stories.)
    news9_box = []
    sel3 = selection_box_9NEWS.get('1.0',END)
    news9_box.append(sel3)

    #### Bundaberg Display - (This stores the users selected stories.)
    BUND_box = []
    sel4 = selection_box_BUND.get('1.0',END)
    BUND_box.append(sel4)

    #### This section combines all the selections above. and displays them.
    #### Using a final_selection method allows the user to update their
    #### selection and the display also updates accordingly
    final_selection = sbs_box + dailymail_box + news9_box + BUND_box
    selection_box.delete('0.0',END)
    list_format = ('\n'.join(final_selection))
    selection_box.insert('0.0', list_format)



####################################################################################################
##################################### (1 - 10) Selectors ###########################################
   
#### Number of stories selector SBS 
numbers = [0,1,2,3,4,5,6,7,8,9,10]
variable = StringVar(user_interface)
variable.set(numbers[0])
variable.trace('w',selection)
SBS = OptionMenu(user_interface, variable, *numbers)


#### Number of stories selector DAILYMAIL 
numbers2 = [0,1,2,3,4,5,6,7,8,9,10]
variable2 = StringVar(user_interface)
variable2.set(numbers2[0])
variable2.trace('w',selection)
DAILYMAIL = OptionMenu(user_interface, variable2, *numbers2)

    
#### Number of stories selector 9 NEWS
numbers3 = [0,1,2,3,4,5,6,7,8,9,10]
variable3 = StringVar(user_interface)
variable3.set(numbers3[0])
variable3.trace('w',selection)
NEWS9 = OptionMenu(user_interface, variable3, *numbers3)


#### Number of stories selector Bundaberg
numbers4 = [0,1,2,3,4,5,6,7,8,9,10]
variable4 = StringVar(user_interface)
variable4.set(numbers4[0])
variable4.trace('w',selection)
BUND = OptionMenu(user_interface, variable4, *numbers4)

####################################################################################################
####################################### Export Button ##############################################


#### Export Button --> Creates the html page and displays everything
#### ------------------------------------------------------------ ####  

descriptions_list_BUND = []
descriptions_list_9NEWS = []
descriptions_list_DAILYMAIL = []
descriptions_list = []
headings_list = []
links_list = []
def export_button():

    #### Opens the HTML Document
    html_page = open(news_file_name, 'w')

    #### ------------------------------------------------------------ #### 
    #### SBS
    inputValue = hidden_selection.get('1.0',END)   #### getting image links
    links_list = findall(r'<link>(.*?)</link>',inputValue)  #### image links put into a list
    headings_dates = selection_box.get('1.0',END)   #### getting headings and dates
    headings_list = findall(r'"(.*?)"',headings_dates)  #### putting headings into list
    dates_list = findall(r'\[(.*?)\]',headings_dates)   #### putting dates into list
    descriptions_list = description_selection.get('1.0',END)  #### getting descrtiptions
    description_list2 = findall(r'<\!\[CDATA\[(.*?)\]\]>', descriptions_list)  #### putting desctiptions into list

    #### ------------------------------------------------------------ #### 
    #### DAILY MAIL
    inputValue_DAILYMAIL = hidden_selection_DAILYMAIL.get('1.0',END)
    links_list_DAILYMAIL = findall(r'<link>(.*?)</link>',inputValue_DAILYMAIL)
    headings_dates_DAILYMAIL = selection_box_DAILYMAIL.get('1.0',END)
    dates_list_DAILYMAIL = findall(r'\[(.*?)\]',headings_dates_DAILYMAIL)
    headings_list_DAILYMAIL = findall(re.compile(r'\"(.*?)\"',re.DOTALL), headings_dates_DAILYMAIL)
    descriptions_list_DAILYMAIL = description_selection_DAILYMAIL.get('1.0',END)
    descriptions_list_DAILYMAIL = findall(r'\n	(.*?)\n',descriptions_list_DAILYMAIL)

    #### ------------------------------------------------------------ #### 
    #### 9 NEWS
    inputValue_9NEWS = hidden_selection_9NEWS.get('1.0',END)
    links_list_9NEWS = findall(r'<link>(.*?)</link>',inputValue_9NEWS)
    headings_dates_9NEWS = selection_box_9NEWS.get('1.0',END)
    dates_list_9NEWS = findall(r'\[(.*?)\]',headings_dates_9NEWS)
    headings_list_9NEWS = findall(r'\"(.*?)\"',headings_dates_9NEWS)
    descriptions_list_9NEWS = description_selection_9NEWS.get('1.0',END)
    descriptions_list_9NEWS = findall(r'<\!\[CDATA\[(.*?)\]\]>', descriptions_list_9NEWS)

    #### ------------------------------------------------------------ #### 
    #### Bundaberg
    inputValue_BUND = hidden_selection_BUND.get('1.0',END)
    links_list_BUND = findall(r'<link>(.*?)</link>',inputValue_BUND)
    headings_dates_BUND = selection_box_BUND.get('1.0',END)
    dates_list_BUND = findall(r'\[(.*?)\]',headings_dates_BUND)
    headings_list_BUND = findall(r'\"(.*?)\"',headings_dates_BUND)
    descriptions_list_BUND = description_selection_BUND.get('1.0',END)
    descriptions_list_BUND2 = findall(r'<(.*?)>', descriptions_list_BUND)     


########################################## HTML PAGE ################################################
    
    #### DOC HEADING
    html_page.write('''

<!DOCTYPE html>
<html>

    <head>
        <!-- Tell Browser to Expext Unicode Chars -->
        <meta charset="utf-8">

        <!-- Title for Browser Window or Tab -->
        <title>HADDAD NEWS</title>

        
        <meta name="description" content="Your one stop shop news source.">

        <!-- Heading Image / Splash Image -->
        <img class="image logo" src="logo_island.png" alt ="Haddad News Logo">

        <!-- Styling -->
        <style type ="text/css">
        
            html { 
                background: #e6e9e9;
                background-image: linear-gradient(270deg, rgb(230, 233, 233) 0%, rgb(221, 221, 221) 100%);
                -webkit-font-smoothing: antialiased;
                
            }
            
            body {
                background: cadetblue;
                box-shadow: 0 0 2px rgba(0, 0, 0, 0.06);
                color: black;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-size: 16px;
                line-height: 1.5;
                text-align: center;
                margin: 0 auto;
                max-width: 800px;
                padding: 2em 2em 4em;
    
            }
            
            img:not(.logo) {
            animation: colorize 2s cubic-bezier(0, 0, .78, .36) 1;
            background: transparent;
            border: 10px solid rgba(0, 0, 0, 0.12);
            border-radius: 4px;
            display: block;
            margin: 1.3em auto;
            max-width: 95%;
            }

            .logo {
                animation: colorize 2s cubic-bezier(0, 0, .78, .36) 1;
                background: transparent;
                display: block;
                margin: 1.3em auto;
                max-width: 95%;
            }

            h1 {
                color:darkslateblue;
            }
            h2 {
                color:black;
            }

            h3 {
                color:darkslateblue;
            }
            hr {
                width: 95%
                font-size: 1px;
                color:darkslateblue;
                line-height: 1px;

                background-color: grey;
                margin-top: -6px;
                margin-bottom: 10px;
            }

        </style>
    </head>
    <body>

        <!-- Article Heading -->
        <h1>HADDAD NEWS</h1>
                    ''')

    #### ------------------------------------------------------------ ####
    #### SBS SECTION
    html_page.write('\n\n<!-- ################################ SBS SECTION ################################ -->\n\n')
    
    z = 0
    for val in links_list:
        if z <= len(links_list):
            html_page.write('<!-- Article Heading -->\n')
            html_page.write(str('<h2>' + headings_list[z] + '</h2>\n'))
            html_page.write('<!-- Story Image -->\n')
            html_page.write(str('<img src="' + links_list[z]) + '" width="500" height="300" alt ="Story Image">\n')
            html_page.write('<!-- Description -->\n')
            html_page.write(str('<h3>' + description_list2[z] + '</h3>\n'))
            html_page.write('<!-- Publish Date -->\n')
            html_page.write(str('<h3>' + '[' + dates_list[z] + ']' + '</h3>\n'))
            html_page.write('<!-------------------------------- End of Article -------------------------------->\n\n')
            z = z+1

    #### ------------------------------------------------------------ #### 
    #### Daily Mail Section
    html_page.write('\n\n<!-- ################################ DAILY MAIL SECTION ################################ -->\n\n')
    
    z1 = 0
    for val in links_list_DAILYMAIL:
        if z1 <= len(links_list_DAILYMAIL):
            html_page.write('<!-- Article Heading -->\n')
            html_page.write(str('<h2>' + headings_list_DAILYMAIL[z1] + '</h2>\n'))
            html_page.write('<!-- Story Image -->\n')
            html_page.write(str('<img src="' + links_list_DAILYMAIL[z1]) + '" width="500" height="300" alt ="Story Image">\n')
            html_page.write('<!-- Description -->\n')
            html_page.write(str('<h3>' + descriptions_list_DAILYMAIL[z1] + '</h3>\n'))
            html_page.write('<!-- Publish Date -->\n')
            html_page.write(str('<h3>' + '[' + dates_list_DAILYMAIL[z1] + ']' + '</h3>\n'))
            html_page.write('<!-------------------------------- End of Article -------------------------------->\n\n')
            z1 = z1+1
    
    #### ------------------------------------------------------------ #### 
    #### 9 News Section
    html_page.write('\n\n<!-- ################################ 9 NEWS SECTION ################################ -->\n\n')
            
    z = 0
    for val in links_list_9NEWS:
        if z <= len(links_list_9NEWS):
            html_page.write('<!-- Article Heading -->\n')
            html_page.write(str('<h2>' + headings_list_9NEWS[z] + '</h2>\n'))
            html_page.write('<!-- Story Image -->\n')
            html_page.write(str('<img src="' + links_list_9NEWS[z]) + '" width="500" height="300" alt ="Story Image">\n')
            html_page.write('<!-- Description -->\n')
            html_page.write(str('<h3>' + descriptions_list_9NEWS[z] + '</h3>\n'))
            html_page.write('<!-- Publish Date -->\n')
            html_page.write(str('<h3>' + '[' + dates_list_9NEWS[z] + ']' + '</h3>\n'))
            html_page.write('<!-------------------------------- End of Article -------------------------------->\n\n')
            z = z+1

    #### ------------------------------------------------------------ ####        
    #### Bundaberg Section
    html_page.write('\n\n<!-- ################################ BUNDABERG SECTION ################################ -->\n\n')
    
    z = 0
    for val in links_list_BUND:
        if z <= len(links_list_BUND):
            html_page.write('<!-- Article Heading -->\n')
            html_page.write(str('<h2>' + headings_list_BUND[z] + '</h2>\n'))
            html_page.write('<!-- Story Image -->\n')
            html_page.write(str('<img src="' + links_list_BUND[z]) + '" width="500" height="300" alt ="Story Image">\n')
            html_page.write('<!-- Description -->\n')
            html_page.write(str('<h3>' + descriptions_list_BUND2[z] + '</h3>\n'))
            html_page.write('<!-- Publish Date -->\n')
            html_page.write(str('<h3>' + '[' + dates_list_BUND[z] + ']' + '</h3>\n'))
            html_page.write('<!-------------------------------- End of Article -------------------------------->\n\n')
            z = z+1

    #### ------------------------------------------------------------ #### 

    html_page.write('\n\n<!-- PAGE BREAK -->')
    html_page.write('\n<hr>')

    #### ------------------------------------------------------------ #### 
    
    #### Sources Section
    html_page.write('\n\n<!-- LINKS -->\n')
    html_page.write('''
<ul>
                    ''')

    html_page.write('\t<!-- SBS RSS LINK -->\n')
    if len(links_list) > 0:
        html_page.write('''
<li style="text-align:left;"> <b>SBS NEWS:</b> <a href="http://www.sbs.com.au/news/rss/Section/Top+Stories" target="_blank">http://www.sbs.com.au/news/rss/Section/Top+Stories</a></li>
                        ''')
    html_page.write('<!-- DAILY MAIL RSS LINK -->\n')
    if len(links_list_DAILYMAIL) > 0:
        html_page.write('''
<li style="text-align:left;"> <b>Daily Mail:</b> <a href="https://www.dailymail.co.uk/articles.rss" target="_blank">https://www.dailymail.co.uk/articles.rss</a></li>
                        ''')
    html_page.write('<!-- 9 NEWS RSS LINK -->\n')
    if len(links_list_9NEWS) > 0:
        html_page.write('''
<li style="text-align:left;"> <b>9 NEWS:</b> <a href="https://www.9news.com.au/rss" target="_blank">https://www.9news.com.au/rss</a></li>
                        ''')
    html_page.write('<!-- BUNDABERG RSS LINK -->\n')
    if len(links_list_BUND) > 0:
        html_page.write('''
<li style="text-align:left;"> <b>Bundaberg:</b> <a href="https://www.news-mail.com.au/feeds/rss/homepage/" target="_blank">https://www.news-mail.com.au/feeds/rss/homepage/</a></li>
                        ''')

        
    html_page.write('''
</ul>
                    ''')

    #### ------------------------------------------------------------ ####        
        
    html_page.write('''
    </body>
</html>
                    ''')

###############################################################################################
##################################### Export Button ###########################################
story_export = Button(user_interface, text = 'Export Selections',
                      font = ('Arial', 18),
                      command = export_button)
###############################################################################################
########################################## SQL ################################################



def saver():

    
    #### Retrieves heading and date info for table.
    date_heading = selection_box.get('1.0',END)
    
    # - Headings - #
    table_headings = findall(r'"(.*?)"',date_heading)
 
    # - Publication Date - #
    dates = findall(r'\[.*\- (.*?)\]',date_heading)

    # - Provider - #
    dates2 = findall(r'\[(.*?)\-',date_heading)
    
     
    ###############################################################
    
    #### Creates a connection to the database
    connection = connect(database = 'news_log.db')

    #### Get a pointer into the database
    news_log = connection.cursor()

    #### Clears previous contents of database
    headline_delete = '''
    DELETE FROM selected_stories;
    '''
    news_log.execute(headline_delete)

    
    # ------------------------------------------------- #
    #### things to insert
    
    x = 0
    for item in table_headings:
        sql = 'INSERT INTO selected_stories VALUES\n' + '(\"' + table_headings[x] + '\",\"' + dates2[x] + '\", \"' + dates[x] + '\")'
        news_log.execute(sql)
        x = x+1
        
    # ------------------------------------------------- #
    
    #### Write changes
    connection.commit()

    #### Close the database
    news_log.close()
    connection.close()


#### Save Button
save_button = Button(user_interface, text = 'Save Selections',
                     font = ('Arial', 18),
                     command = saver)





###############################################################################################
################################### Packing Everything ########################################
photo_label.pack(side=LEFT)
news_feed_label.pack()


#### SBS
sbs_label.pack()
SBS.pack()

#### DAILY MAIL
dailymail_label.pack()
DAILYMAIL.pack()

#### 9 NEWS
news_9_label.pack()
NEWS9.pack()

#### Bundaberg
BUND_label.pack()
BUND.pack()

#### Other GUI Elements
story_export.pack()
save_button.pack()
scrollbar.pack(side = RIGHT, fill = Y)
selection_box.pack(side = RIGHT, fill = BOTH)
scrollbar.config(command=selection_box.yview)
user_interface.mainloop()

###############################################################################################

